<?php
   
    $uname=$_POST['uname'];
	
	 $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	
	
	$select = "SELECT Password,Type FROM user WHERE Username='$uname'";
	$data = mysqli_query($c,$select);
    $row = mysqli_fetch_assoc($data);
    echo json_encode($row);
    
?>