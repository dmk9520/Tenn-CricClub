<?php
    $s=null;
    $jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);
    print_r($data_array);
    $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}

    $datagname = $data_array['datagname'];
    $datausername = $data_array['datausername'];
    $datavenue= $data_array['datavenue'];
    $datadate = $data_array['datadate'];
    $datatime = $data_array['datatime'];
    $dataphone = $data_array['dataphone'];
    $datateamone = $data_array['datateamone'];
    $datateamtwo = $data_array['datateamtwo'];
    
    $q =mysqli_query($c, "INSERT INTO match_data SET gname = '$datagname', venue = '$datavenue',date = '$datadate',time = '$datatime',mobile = '$dataphone',teamone='$datateamone',teamtwo='$datateamtwo'");
    echo $q;
      if (!$q) {
		echo"Gamename already taken";
	  }else{
	      echo "Game Created";
	  }
    
?>