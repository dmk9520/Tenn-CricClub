<?php

	$cricketMatchesTxt = file_get_contents('http://cricapi.com/api/cricket/?apikey=ABjytGbbjObRmZ3elZU0xJa59C43');
	
	$cricketMatches = json_decode($cricketMatchesTxt);
    print_r($cricketMatches);
 ?>