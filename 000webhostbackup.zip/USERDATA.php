<?php
   
    $uname=$_POST['uname'];

	$i=0;
	 $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	
	
	$select = "SELECT Firstname,Lastname,Address,Username,DOB,Mobilenumber,Type FROM user WHERE Username='$uname'";
	$data = mysqli_query($c,$select);
	$row = mysqli_fetch_assoc($data);
	$c = count($row);
	echo json_encode($row);
/*	$key=array("fname","lname","address","username","dob","mobile","type");
	$val=array();
	
	for($i=0;$i<$c;$i++)
    {
        $val[$key[$i]] = current($row);
        next($row);
    }

	print_r($val);*/
    
?>