<?php
    $s=null;
    $jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);

   
	 $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	
	$uname = $data_array['user'];
	$query="select * from playerteaminfo where '$uname' in ( player1,player2,player3,player4,player5,player6,player7,player8,player9,player10,player11,player12,player13,player14,player15)";
	if(mysqli_query($c,$query)){
	    echo "1";
	}else{
	    echo "0";
	}
/*	$select = "SELECT Password,Type FROM user WHERE Username='$uname'";
	$data = mysqli_query($c,$select);
    $row = mysqli_fetch_assoc($data);
    echo json_encode($row);*/
?>