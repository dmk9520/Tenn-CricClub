<?php


 $conn = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$conn) 
	{
		die("Error : ".mysqli_error($conn)."<br><br>");
	}
 
 
     
     $ImageData = $_POST['image_path'];
     
     $ImageName = $_POST['image_name'];

    
     $ImagePath = "scorecard/".$ImageName.".png";
     
     
     $ServerURL = "https://tenncricclub.000webhostapp.com/".$ImagePath;
    

         $result = mysqli_query($conn,"insert into scorecard (gname,imgurl) values ('$ImageName','$ServerURL')");
         file_put_contents($ImagePath,base64_decode($ImageData));
        echo "Your Image Has Been Uploaded.";
  
mysqli_close($conn);
?>