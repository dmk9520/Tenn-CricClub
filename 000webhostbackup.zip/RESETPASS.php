<?php
   $jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);
    
	 $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	 $newpass=$data_array['newpass'];
	$mob=$data_array['phone'];
	echo "New Pass : ".$newpass;
	$select = "UPDATE user SET Password='$newpass' WHERE Username = '$mob' OR Mobilenumber='$mob'";
	$data = mysqli_query($c,$select);
	echo $select;
	if(!$data)
	{
	    die("ERROR".$mysqli_error($c));
	}
?>