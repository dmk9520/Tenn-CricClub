<?php
     $con = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	 if (!$con) {
		die("Error : ".mysqli_error($con)."<br><br>");
	 }
     
     $uname = $_REQUEST['uname'];
     $sql = "select image from proimg where Username = '$uname'";
     $r = mysqli_query($con,$sql);
     $row = mysqli_fetch_assoc($r);
    echo $row['image'];  

?>