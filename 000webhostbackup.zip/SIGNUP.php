<?php
    $s=null;
    $jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);
    //print_r($data_array);
    $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}

    $fname = $data_array['fname'];
    $lname= $data_array['lname'];
    $address = $data_array['address'];
    $uname = $data_array['uname'];
    $dob = $data_array['dob'];
    $mobilenumber = $data_array['phone'];
    $password = $data_array['password'];
    $type = $data_array['type'];

    $q = "INSERT INTO user SET Firstname = '$fname', Lastname = '$lname',Address = '$address',Username = '$uname',DOB = '$dob',Mobilenumber = '$mobilenumber',Password = '$password',Type = '$type'";
    
    $r=mysqli_query($c,$q);
	  if (!$r) {
		die("Username already taken!!");
	  }
    
?>