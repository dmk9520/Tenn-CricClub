<?php

$jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);

 $conn = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$conn) {
		die("Error : ".mysqli_error($conn)."<br><br>");
	}
 
    print_r($data_array);
    $fname = $data_array['fname'];
    $lname= $data_array['lname'];
    $address = $data_array['address'];
    $uname = $data_array['uname'];
    $dob = $data_array['dob'];
    $mobilenumber = $data_array['phone'];
    $password = $data_array['password'];
    $existpassword = $data_array['existpassword'];

//	echo $uname." ".$existpassword." ".$password;
	$select = mysqli_query($conn,"SELECT Password FROM user WHERE Username='$uname'");
	$row = mysqli_fetch_assoc($select);
	$pass = $row['Password'];
echo $pass;
	if($pass === $existpassword)
	{
		$updatequery=mysqli_query($conn,"UPDATE user SET Firstname = '$fname', Lastname = '$lname',Address = '$address',DOB = '$dob',Mobilenumber = '$mobilenumber',Password = '$password' WHERE Username = '$uname'");
	
	
			echo "Profile Updated";
		
	}else {
		
		echo"Invalid Existing Password";
	}

?>