<?php
    $s=null;
    $jdata=$_POST['jdata'];
    $data_array = json_decode($jdata,true);
    $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	
	static $total=1;
	$uname = $data_array['uname'];
	$team = $data_array['team'];
	$gname = $data_array['gname'];
	$query= "select totalplayer from playerteaminfo where gname=$gname";
	$result = mysqli_query($c,$query);
	
	if($result){
    	while($row = mysqli_fetch_assoc($result)){
    	    $total=$row['totalplayer'];
    	    echo $total."player are joined";
    	}
	}
	if($total<15){
	$query=mysqli_query($c,"insert into playerteaminfo(gname,teamname,player$total,totalplayer) values('$gname','$team','$uname',$total)"); 
	$total++;

    if($query){
	    die("Congrats! You are successfully added");
	}else{
	    die(mysqli_error($c));
	}
	
	}else {
	    die("Team already full");
	}
	
	
	
?>