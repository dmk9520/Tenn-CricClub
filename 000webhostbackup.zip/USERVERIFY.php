<?php
	
	 $c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	/*
	if($_POST['number'])
	{*/
    	 $num = $_POST['number'];
    	 //$u = $_POST['uname'];
    	// echo $_POST['number'];
    	$select = "SELECT Mobilenumber FROM user WHERE Mobilenumber='$num' OR Username='$num'";
    	$data = mysqli_query($c,$select);
    	while($row = mysqli_fetch_assoc($data))
    	{
    	    echo $row['Mobilenumber']; 
    	}
	//} 
/*	else if($_POST['uname'])
	{
    	$u = $_POST['uname'];
    	//echo $_POST['uname'];
    	$select1 = "SELECT Mobilenumber FROM user WHERE Username='$u'";
    	$data1 = mysqli_query($c,$select1);
    	while($row1 = mysqli_fetch_assoc($data1))
    	{
    	    echo $row1['Mobilenumber']; 
    	}
	} */
    
?>