<?php
   
    $i=0;
	$c = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$c) {
		die("Error : ".mysqli_error($c)."<br><br>");
	}
	
	
	$select = "SELECT * FROM match_data";
	$data = mysqli_query($c,$select);
	$fetchdata=[];
	if($data)
	{
	   $i=0;
	    while($row = mysqli_fetch_assoc($data))
	    {
	        $fetchdata[$i] = $row;
	        $i++;
	    }
	    
    }
    echo json_encode($fetchdata);
    
?>