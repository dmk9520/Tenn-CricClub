<?php


 $conn = mysqli_connect("localhost","id5216565_root","tenncricclub040925","id5216565_tenncricclub");
	if (!$conn) 
	{
		die("Error : ".mysqli_error($conn)."<br><br>");
	}
 
 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
     
     $ImageData = $_POST['image_path'];
     
     $ImageName = $_POST['image_name'];
/*    
     $GetOldIdSQL ="SELECT id FROM imgtemp ORDER BY id ASC";
     
     $Query = mysqli_query($conn,$GetOldIdSQL);
     
     while($row = mysqli_fetch_array($Query))
     {
     
         $DefaultId = $row['id'];
     }*/
     $ImagePath = "images/$ImageName.png";
     
     $ServerURL = "https://tenncricclub.000webhostapp.com/".$ImagePath;
     
     $select ="Select * from proimg where Username='$ImageName'";
    
     $user = mysqli_query($conn,$select);
     $row = mysqli_fetch_assoc($user);
     $uname = $row['Username'];
 
    

    if($ImageName===$uname)
     {
         $result = mysqli_query($conn,"UPDATE image=$ServerURL where Username=$ImageName");
         file_put_contents($ImagePath,base64_decode($ImageData));
         echo "Your Image Has Been Updated."; 
     }
     else{
         $result = mysqli_query($conn,"insert into proimg (Username,image) values ('$ImageName','$ServerURL')");
         file_put_contents($ImagePath,base64_decode($ImageData));
        echo "Your Image Has Been Uploaded.";
     }
     
     	
  
     //$InsertSQL = "insert into proimg (Username,image) values ('$ImageName','$ServerURL')";
     
     
   /*
     $result = mysqli_query($conn,"UPDATE image=$ServerURL where Username=$ImageName");		 
    
    if (mysqli_affected_rows($conn)==0) 
    {
    	$result = mysqli_query($conn,$InsertSQL);
    	
    	file_put_contents($ImagePath,base64_decode($ImageData));
        echo "Your Image Has Been Uploaded.";
    }
    echo "Profile Picture Updated.";*/
    /* if(mysqli_query($conn, $q))
     {
        
         
     }*/
 
 }
 /*else
 {
    echo "Not Uploaded";
 }*/

 mysqli_close($conn);
?>